﻿using System.ComponentModel.DataAnnotations;

namespace WebAppProject.Models
{
    public class GroceryItem
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        public int StockAmount { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [StringLength(255)]
        public string ImageUrl { get; set; }
    }
}
