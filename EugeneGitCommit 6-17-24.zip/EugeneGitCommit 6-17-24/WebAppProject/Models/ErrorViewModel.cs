﻿using System.ComponentModel.DataAnnotations;

namespace WebAppProject.Models;

public class ErrorViewModel
{
    public string? RequestId { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}
