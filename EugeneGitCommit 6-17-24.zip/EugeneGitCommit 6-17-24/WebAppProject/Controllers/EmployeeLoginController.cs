﻿using Microsoft.AspNetCore.Mvc;
using WebAppProject.Data;
using WebAppProject.Models;
using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using System.Threading.Tasks;

namespace WebAppProject.Controllers
{
    public class EmployeeLoginController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeLoginController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: EmployeeLogin
        public IActionResult Index()
        {
            return View();
        }

        // POST: EmployeeLogin
        [HttpPost]
        public async Task<IActionResult> Login(EmployeeLogin model)
        {
            if (ModelState.IsValid)
            {
                var employee = _context.Employees.FirstOrDefault(e => e.UserName == model.Username && e.Password == model.Password);

                if (employee != null)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, employee.UserName),
                        new Claim(ClaimTypes.Role, employee.Role)
                    };

                    var identity = new ClaimsIdentity(claims, "EmployeeLogin");
                    var principal = new ClaimsPrincipal(identity);
                    await HttpContext.SignInAsync(principal);

                    if (employee.Role == "Admin")
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    else
                    {
                        return RedirectToAction("Index", "Employee");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid username or password");
                }
            }

            return View(model);
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}
