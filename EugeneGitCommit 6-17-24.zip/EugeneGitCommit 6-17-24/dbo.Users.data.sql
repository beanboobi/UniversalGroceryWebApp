﻿INSERT INTO Users (Username, Password, Name, Email)
VALUES ('testuser1', 'password1', 'Test User 1', 'testuser1@example.com');

INSERT INTO Users (Username, Password, Name, Email)
VALUES ('testuser2', 'password2', 'Test User 2', 'testuser2@example.com');
